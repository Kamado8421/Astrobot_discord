// iniciando importações
const {
  Client, 
  Events,
  GatewayIntentBits,
  Collection 
} = require('discord.js');
const fs = require('fs');
const path = require('path');

// carregando arquivo de configuração 
const config = JSON.parse(fs.readFileSync('./src/config.json', 'utf8'));

// setando configurações às variáveis 
const token = config.token;
const guildId = config.guild_id;
const clientId = config.client_id;

// importando função / classes personalizadas
const getCommandList = require('./src/actions/getCommandList.js');

// instanciando bot
const bot = new Client({ intents: [GatewayIntentBits.Guilds] });

// quando bot for logado
bot.once(Events.ClientReady, c => {
  console.log(`Pronto!! Bot ${c.user.tag} logado!`);
});

// iniciando login com autenticação 
bot.login(token);

// adiciona os comandos disponíveis ao bot
const commandFound = getCommandList();

bot.commands = new Collection();
for(let i = 0; i < commandFound.length; i++){
  bot.commands.set(commandFound[i].data.name, commandFound[i]);
}

// ouvindo to-do tipo de interação do chat
bot.on(Events.InteractionCreate, interaction => {
  // se não for mensagem, fica de boa
  // if(!interaction.ChatInputCommandInteraction) return;
  
  //console.log(interaction)
  
  // variáveis que poderão ser utilizadas
  const serverId = interaction.guildId;
  const channelId = interaction.channelId;
  const user = interaction.user;
  
  // pegando infos do usuário
  const userName = user.username;
  const pushName = user.globalName;
  
  // servidor
  const serverName = interaction?.member?.guild?.name;
  
  // se a mensagem for de um bot, não responda
  if(user.bot) return;
  
  // comando recebido
  const command = interaction.commandName;
  
  console.log(`
  Servidor: ${serverName}
  Usuário: ${userName}
  Nome público: ${pushName}
  Comando: ${command}`)
  
});

