// classe onde poderemos criar metodos para envio tipos de msgs
class Messagem {
  constructor(botinteracao){
    this.botinteracao = botinteracao;
  }
  
  // envia msg de texto
  async enviar(text){
    await this.botinteracao.reply(text)
  }
}