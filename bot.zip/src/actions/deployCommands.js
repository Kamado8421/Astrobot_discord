const { REST, Routes } = require('discord.js');
// navegação de diretórios
const fs = require('fs');
const path = require('path');

const config = JSON.parse(fs.readFileSync('../config.json', 'utf8'));

// setando configurações às variáveis 
const token = config.token;
const guildId = config.guild_id;
const clientId = config.client_id;

const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

const commands = [];

for(const file of commandFiles){
  const command = require(`./commands/${file}`);
  commands.push(command.data.toJSON());
}

const rest = new REST({ version: 10 }).setToken(token);

(async () => {
  try {
    console.log(`Resetando ${commands.length} comandos…`);
    const data = await rest.put(
      Routes.applicationGuildCommands(clientId, guildId),
      {body: commands}
      );
      
    console.log(`Comandos Registrados com sucesso`);
  } catch(error){
    console.error(error);
  }
})()

