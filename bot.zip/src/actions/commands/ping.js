const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Comando para mostrar se o bot está ativo.'),
    
  async execute(interaction){
    await interaction.reply('ping🏓');
  }
}



