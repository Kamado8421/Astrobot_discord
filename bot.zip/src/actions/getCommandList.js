// navegação de diretórios
const fs = require('fs');
const path = require('path');

// importações de comandos
module.exports = async function getCommandList(){
  // lista de comandos (primeiramente vazia)
  let commands_found = [];
  
  // procurando o diretório de comandos
  const commandsPath = await path.join(__dirname, "commands");
  const commandFiles = await fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
  
  // percorre todos os arquivos da pasta comandos
  for(const file of commandFiles){
    const filePath = await path.join(commandsPath, file);
    const command = require(filePath);
    
    // verifica se possui objeto necessário de um cmd
    if("data" in command && "execute" in command){
      // joga no array os cmd encontrados
      commands_found.push(command);
    } else {
      console.log(`O arquivo comando em ${filePath} não foi identificado como comando.`)
    }
  }
  
  return commands_found;
}
